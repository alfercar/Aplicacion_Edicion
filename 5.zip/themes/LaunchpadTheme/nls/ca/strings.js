define({
  "_themeLabel": "Tema Launchpad",
  "_layout_default": "Disseny per defecte",
  "_layout_right": "Disseny dret"
});