define({
  "_themeLabel": "Tema Plataforma de Lançamento",
  "_layout_default": "Layout predefinido",
  "_layout_right": "Layout direita"
});