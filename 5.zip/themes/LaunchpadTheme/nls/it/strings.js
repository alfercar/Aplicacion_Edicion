define({
  "_themeLabel": "Tema Rampa di lancio",
  "_layout_default": "Layout predefinito",
  "_layout_right": "Layout destra"
});