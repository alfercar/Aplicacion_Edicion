define({
  "_themeLabel": "Temă platformă lansare",
  "_layout_default": "Aspect implicit",
  "_layout_right": "Aspect corect"
});