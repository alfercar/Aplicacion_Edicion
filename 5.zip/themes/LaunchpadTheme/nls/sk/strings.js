define({
  "_themeLabel": "Motív Launchpad",
  "_layout_default": "Predvolené rozloženie",
  "_layout_right": "Rozloženie vpravo"
});