define({
  "_themeLabel": "Thème Barre de lancement",
  "_layout_default": "Mise en page par défaut",
  "_layout_right": "Mise en page à droite"
});