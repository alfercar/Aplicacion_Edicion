define({
  "_widgetLabel": "Στοιχείο ελέγχου μπάρας αγκύρωσης",
  "_layout_default": "Προεπιλεγμένη διάταξη",
  "_layout_layout1": "Διάταξη 0",
  "more": "Περισσότερα widget"
});